"use client";

import HeroMedia from "./HeroMedia";
import HeroContent from "./HeroContent";
import HeroScrollIndicator from "./HeroScrollIndicator";
import useAmbient from "@/src/components/ambient/useAmbient";

export default function Hero() {
  useAmbient("hero");
  return (
    <section
      className="
        relative
        isolate
        min-h-[130vh]
        overflow-hidden
        
      "
    >
      {/* Background Campaign */}
      <HeroMedia />

      {/* Hero Content */}
      <div
        className="
          absolute
          inset-0
          z-10
          h-full
        "
      >
        <HeroContent />
      </div>

      {/* Scroll Indicator */}
      <HeroScrollIndicator />
    </section>
  );
}