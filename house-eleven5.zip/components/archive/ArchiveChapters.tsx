"use client";

import { motion } from "framer-motion";

import Section from "@/components/layout/Section";
import ArchiveFrame from "./ArchiveFrame";
import ArchiveDivider from "./ArchiveDivider";

import {
  Eyebrow,
  Display,
  Body,
} from "@/components/ui/typography";

import { fadeUp } from "@/lib/motion";

export default function ArchiveChapters() {
  return (
    <Section padding="pt-16 pb-24">
      <ArchiveFrame>
        <motion.div
          {...fadeUp}
          className="max-w-3xl"
        >
          <Eyebrow>
            Chapters
          </Eyebrow>

          <Display className="mt-8">
            The permanent
            collection of the House.
          </Display>

          <Body
            className="
              mt-10
              max-w-2xl
              text-white/60
            "
          >
            Every collection is preserved as a chapter in the
            evolving record of House Eleven—documenting not only
            what was created, but what the House believed at that
            moment in time.
          </Body>

          <ArchiveDivider className="mt-20 mb-0" />
        </motion.div>
      </ArchiveFrame>
    </Section>
  );
}