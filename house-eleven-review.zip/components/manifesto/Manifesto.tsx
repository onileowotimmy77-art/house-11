"use client";

import Section from "@/components/layout/Section";
import Container from "@/components/layout/Container";

import ManifestoHeader from "./ManifestoHeader";
import ManifestoIntro from "./ManifestoIntro";
import ManifestoStatements from "./ManifestoStatements";
import ManifestoClosing from "./ManifestoClosing";
import useAmbient from "@/src/components/ambient/useAmbient";

export default function Manifesto() {
  useAmbient("manifesto");
  return (
    <Section padding="py-56">
      <Container>

        <ManifestoHeader />

        <ManifestoIntro />

        <ManifestoStatements />

        <ManifestoClosing />

      </Container>
    </Section>
  );
}