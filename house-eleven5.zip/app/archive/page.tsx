import {
  ArchiveThreshold,
  ArchivePrologue,
  ArchiveTimeline,
  ArchiveChapters,
  ArchiveChapter,
} from "@/components/archive";

export default function ArchivePage() {
  return (
    <main className="bg-background text-foreground min-h-screen">
      <ArchiveThreshold />

      <ArchivePrologue />

      <ArchiveTimeline />

      <ArchiveChapters />

      <ArchiveChapter />
      
    </main>
  );
}